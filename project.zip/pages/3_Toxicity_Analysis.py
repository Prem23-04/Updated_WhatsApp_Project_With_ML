import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline

st.set_page_config(page_title="Toxicity Detection", layout="wide")

st.title("☠ WhatsApp Toxicity Detection (ML-Based)")

# Check if chat data exists in session
if 'chat_df' not in st.session_state:
    st.warning("⚠ Upload a chat in the Chat Analyzer first.")
    st.stop()

df = st.session_state['chat_df'].copy()

st.info("✔ Chat loaded — training toxicity model now...")

# ================== Auto Label Using Toxic Word Lists ==================

toxic_words = [
    "idiot","stupid","hate","loser","kill","dumb","mad","angry","fool",
    "bloody","shit","fuck","hell","bitch","moron","trash","abuse",
    "ugly","annoy","shut up","nonsense","crap"
]

def weak_label(msg):
    msg_l = msg.lower()
    if any(w in msg_l for w in toxic_words):
        return "Toxic"
    return "Clean"

df['toxicity_label'] = df['message'].apply(weak_label)

# Need at least some toxic messages to train
train_df = df[df['toxicity_label'] == "Toxic"]

if train_df.empty or train_df.shape[0] < 3:
    st.warning("⚠ Not enough toxic examples to train ML. Try a chat with more arguments 😅")
    st.stop()

# ================== Train ML model ==================
pipe = Pipeline([
    ('tfidf', TfidfVectorizer(stop_words='english')),
    ('clf', LogisticRegression(max_iter=200))
])

pipe.fit(df['message'], df['toxicity_label'])

st.success("🎯 Toxicity model trained successfully!")

# ================== Predict Toxicity ==================
df['predicted_toxicity'] = pipe.predict(df['message'])

# ================== Toxicity Stats ==================
st.subheader("📊 Clean vs Toxic Messages")

count = df['predicted_toxicity'].value_counts()

fig, ax = plt.subplots()
count.plot(kind='bar', color=['red','green'], ax=ax)
ax.set_ylabel("Messages")
st.pyplot(fig)

# ================== Daily Toxicity Trend ==================
st.subheader("📈 Toxicity Over Time")

daily = df.groupby(df['date'].dt.date)['predicted_toxicity'].agg(lambda x: (x=='Toxic').mean())
st.line_chart(daily)

# ================== Show Toxic Messages ==================
st.subheader("🚨 Detected Toxic Messages")
st.write(df[df['predicted_toxicity'] == "Toxic"][['date','user','message']])

# ================== Show Clean Messages Option ==================
with st.expander("Show Clean Messages"):
    st.write(df[df['predicted_toxicity'] == "Clean"][['date','user','message']])

st.success("☠ Toxicity analysis complete!")
