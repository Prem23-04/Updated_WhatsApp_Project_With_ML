import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline

st.set_page_config(page_title="Sentiment Analysis", layout="wide")

st.title("💬 WhatsApp Sentiment Analysis (ML-based)")

# Check if chat data exists in session
if 'chat_df' not in st.session_state:
    st.warning("⚠ Upload a chat in the main Chat Analyzer first.")
    st.stop()

df = st.session_state['chat_df'].copy()

st.info("✔ Chat data loaded from memory!")

# ===== Step 1: Auto-label messages =====
positive_words = ["good","great","awesome","nice","love","best","happy","joy","fun","cool","beautiful","amazing"]
negative_words = ["bad","sad","hate","angry","worst","cry","upset","terrible","boring","annoy","stupid","problem"]

def weak_label(text):
    text_l = text.lower()
    if any(w in text_l for w in positive_words):
        return "Positive"
    elif any(w in text_l for w in negative_words):
        return "Negative"
    else:
        return "Neutral"

df['sentiment'] = df['message'].apply(weak_label)

# Remove rows too small for training
train_df = df[df['sentiment'] != "Neutral"]

if train_df.empty:
    st.warning("Not enough positive/negative messages to train ML. Try a larger chat.")
    st.stop()

# ===== Step 2: Train ML model =====
st.subheader("🤖 Training ML Model (TF-IDF + Logistic Regression)")

pipe = Pipeline([
    ('tfidf', TfidfVectorizer(stop_words='english')),
    ('clf', LogisticRegression())
])

pipe.fit(train_df['message'], train_df['sentiment'])

st.success("🎉 Model trained successfully on uploaded chat!")

# ===== Step 3: Predict sentiments =====
df['predicted_sentiment'] = pipe.predict(df['message'])

# ===== Stats =====
st.subheader("📊 Sentiment Prediction Counts")
counts = df['predicted_sentiment'].value_counts()

fig, ax = plt.subplots()
counts.plot(kind='bar', ax=ax, color=['green','red','gray'])
st.pyplot(fig)

# ===== Sentiment Over Time =====
st.subheader("📈 Sentiment Trend")
daily = df.groupby(df['date'].dt.date)['predicted_sentiment'].agg(lambda x: (x=='Positive').mean())
st.line_chart(daily)

# ===== Show messages =====
st.subheader("💬 Messages Classified by ML")
st.dataframe(df[['date','user','message','predicted_sentiment']], use_container_width=True)

st.success("✔ ML-based sentiment analysis completed!")
